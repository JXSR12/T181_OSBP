package myproj;

import java.util.Scanner;

public class Controller implements Runnable{
	Scanner input = new Scanner(System.in);
	private String inputted;
	
	public static void pause() {
        try {
            System.in.read();
        } catch (Exception e) {
        }
    }
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		inputted = "";
		while(true) {
			MainSystem.setAction(0);
			do {
				inputted = input.nextLine();
			}while (!inputted.equals("1") && !inputted.equals("2") && !inputted.equals("3"));
			
			if(inputted.equals("1")) {
				MainSystem.setAction(1);
				System.out.println("HALT, Insert Food!");
				pause();
			}
			
		}
	}
	
	

}
