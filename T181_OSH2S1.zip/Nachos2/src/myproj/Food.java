package myproj;

public class Food {
	private String name;
	private String desc;
	private int price;
	private long finishTime;
	private long burntTime;
	private boolean isFinished;
	private boolean isBurnt;

	public Food(String name, String desc, int price, int initTime) {
		// TODO Auto-generated constructor stub
		this.name= name;
		this.desc = desc;
		this.price = price;
		this.finishTime = MainSystem.getSeconds() + initTime;
		this.burntTime = finishTime+10;
		this.isFinished = false;
		this.isBurnt = false;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public long getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(long finishTime) {
		this.finishTime = finishTime;
	}

	public long getBurntTime() {
		return burntTime;
	}

	public void setBurntTime(long burntTime) {
		this.burntTime = burntTime;
	}

	public boolean isFinished() {
		return isFinished;
	}

	public void setFinished(boolean isFinished) {
		this.isFinished = isFinished;
	}

	public boolean isBurnt() {
		return isBurnt;
	}

	public void setBurnt(boolean isBurnt) {
		this.isBurnt = isBurnt;
	}
	
	
	
	
	
}
