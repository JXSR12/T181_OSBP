package myproj;

import nachos.machine.Machine;
import nachos.machine.Timer;
import nachos.threads.Semaphore;

public class MainSystem {
	private static MyConsole console;
	private static int lives = 3;
	private static int money = 0;
	private static long seconds = 0;
	private static int action = 0;
	private String inputted;
	private static Oven oven = new Oven();
	
	public static void clrscr() {
		for(int i = 0; i < 60; i++) {
			System.out.println();
		}
	}
	
	public static void pause() {
        try {
            System.in.read();
        } catch (Exception e) {
        }
    }
	
	public MainSystem() {
		console = new MyConsole();
		Timer timer = Machine.timer();
		Runnable handler = new Runnable() {
			public void run() {
				if(lives <= 0) {
					clrscr();
					setSeconds(0);
					System.out.println("GAME OVER!");
					System.out.println("===================");
					System.out.println("Your lives is at 0");
					System.out.println("===================");
					pause();
					
					return;
				}
				if(action == 0) {
					clrscr();
					setSeconds(timer.getTime()/1000000);
					 System.out.println("ovEn Manager\n");
					 System.out.println("============\n");
					 System.out.println("Lives = "+lives);
					 System.out.println("\nMoney = "+money);
					 System.out.println("\nSeconds Elapsed = "+getSeconds());
				}
				oven.updateFoods();
								
			}
		};
		
		timer.setInterruptHandler(handler);
		new Semaphore(0).P();
	}

	public static MyConsole getConsole() {
		return console;
	}

	public static long getSeconds() {
		return seconds;
	}

	public static void setSeconds(long seconds) {
		MainSystem.seconds = seconds;
	}

	public static int getLives() {
		return lives;
	}

	public static void setLives(int lives) {
		MainSystem.lives = lives;
	}

	public static int getMoney() {
		return money;
	}

	public static void setMoney(int money) {
		MainSystem.money = money;
	}

	public static int getAction() {
		return action;
	}

	public static void setAction(int action) {
		MainSystem.action = action;
	}

	public String getInputted() {
		return inputted;
	}

	public void setInputted(String inputted) {
		this.inputted = inputted;
	}

	public static void setConsole(MyConsole console) {
		MainSystem.console = console;
	}
	
	
	
	
	
	
}
