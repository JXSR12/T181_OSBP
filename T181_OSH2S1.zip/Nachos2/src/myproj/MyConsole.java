package myproj;

import nachos.machine.Machine;
import nachos.machine.SerialConsole;
import nachos.threads.Semaphore;

public class MyConsole {
	SerialConsole sc = Machine.console();
	Semaphore sem = new Semaphore(0);
	char input;
	
	public MyConsole() {
		Runnable receive = new Runnable() {
			public void run() {
				input = (char) sc.readByte();
				sem.V();
			}
		};
		
		Runnable send = new Runnable() {
			
			public void run() {
				sem.V();
			}
		};
		
		
		sc.setInterruptHandlers(receive, send);
	}
	
	public void write(String str){
		for(int i=0; i<str.length(); i++){
			this.sc.writeByte(str.charAt(i));
			sem.P();
		}
	}
	
	public void writeln(String str){
		write(str+'\n');
	}
	
	public String read(){
		String result = "";
		do{
			sem.P();
			if(input != '\n'){
				result+= input;
			}
		}while(input != '\n');
		return result;
	}
	
	public int readInt(){
		int result = 0;
		try {
			result = Integer.parseInt(read());
		} catch (Exception e) {
			result = -99999;
		}
		return result;
	}
}
