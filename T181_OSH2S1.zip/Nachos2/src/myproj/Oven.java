package myproj;

import java.util.ArrayList;

public class Oven {
	private static ArrayList<Food> foods = new ArrayList<>();
	private MyConsole cn;
	
	public static void clrscr() {
		for(int i = 0; i < 60; i++) {
			System.out.println();
		}
	}
	
	public static void pause() {
        try {
            System.in.read();
        } catch (Exception e) {
        }
    }
	

	public Oven() {
		// TODO Auto-generated constructor stub
		cn = MainSystem.getConsole();
	}
	
	public void insertFood() {
		MainSystem.setAction(1);
		clrscr();
		String newName = "";
		String newDesc = "";
		int newPrice = 0;
		int newTime = 0;
		while(newName.length() <= 0) {
			System.out.print("Food Name : ");
			newName = cn.read();
		}
		while(newDesc.length() <= 0) {
			System.out.print("Food Desc : ");
			newDesc = cn.read();
		}
		while(newPrice <= 0) {
			System.out.print("Food Price : ");
			newPrice = cn.readInt();
		}
		while(newTime <= 0) {
			System.out.print("Food Time : ");
			newTime = cn.readInt();
		}
		pause();
		MainSystem.setAction(0);
		foods.add(new Food(newName,newDesc,newPrice,newTime));
		
	}
	
	public void takeFood(int rIn) {
		int sel = -1;
		while(sel <= 0) {
			System.out.printf("Enter Number in Oven [%d - %d]\n",1,1);
		}
		
		if(foods.get(rIn-1) != null) {
			Food f = foods.get(rIn-1);
			if(f.isFinished()) {
				displaySuccess(f);
			}else {
				displayTooSoon(f);
			}
		}
	}
	
	public void updateFood(int rIn) {
		MainSystem.setAction(1);
		if(foods.get(rIn-1) != null) {
			clrscr();
			int newTime = 0;
			while(newTime <= 0) {
				System.out.print("Additional Food Time : ");
				newTime = cn.readInt();
			}
			pause();
			MainSystem.setAction(0);
			
		}
	}
	
	public void updateFoods() {
		for(Food f : foods) {
			if(!f.isFinished() && MainSystem.getSeconds() >= f.getFinishTime()) {
				f.setFinished(true);
			}
			if(!f.isBurnt() && MainSystem.getSeconds() >= f.getBurntTime()) {
				f.setBurnt(true);
			}
			if(f.isBurnt()) {
				displayBurnt(f);
				foods.remove(f);
			}
		}
	}
	
	public void displayBurnt(Food f) {
		MainSystem.setAction(1);
		clrscr();
		System.out.println(f.getName()+" is burnt! Your lives have been decremented by 1.");
		MainSystem.setLives(MainSystem.getLives()-1);
		pause();
		MainSystem.setAction(0);
		
	}
	
	public void displaySuccess(Food f) {
		MainSystem.setAction(1);
		clrscr();
		System.out.println(f.getName()+" is finished! Your money have been increased by "+f.getPrice());
		MainSystem.setMoney(MainSystem.getMoney()+f.getPrice());
		pause();
		MainSystem.setAction(0);
		
	}
	
	public void displayTooSoon(Food f) {
		MainSystem.setAction(1);
		clrscr();
		System.out.println(f.getName()+" is uncooked! Your lives have been decremented by 1.");
		MainSystem.setLives(MainSystem.getLives()-1);
		pause();
		MainSystem.setAction(0);
	}
	
	public void printOven() {
		if(foods.isEmpty()) {
			System.out.println("================================================================================================================");
			System.out.println("|                                 Nothing   is   cooking   right   now                                         |");
			System.out.println("================================================================================================================");
		}else {
			System.out.println("================================================================================================================");
			System.out.println("| No.  | Food Name           | Food Desc           | Food Price | Status                                       |");
			System.out.println("================================================================================================================");
		int count = 0;
		for(Food f : foods) {
			count++;
			System.out.printf ("| %-6s| %-19s| %-20s| %-11d| %-45s|\n",count+".",f.getName(),f.getDesc(),f.getPrice(),f.isFinished() ? 
					"Finished, "+(f.getBurntTime()-MainSystem.getSeconds())+" seconds till burnt" : "Unfinished, "+(f.getFinishTime()-MainSystem.getSeconds())+" seconds till finished");
		}
		System.out.println   ("================================================================================================================");
		}
		
		
		
		
	}

	public static ArrayList<Food> getFoods() {
		return foods;
	}

}
