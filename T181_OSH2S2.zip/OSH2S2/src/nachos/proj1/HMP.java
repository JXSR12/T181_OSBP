package nachos.proj1;

import java.util.ArrayList;

import nachos.machine.MalformedPacketException;
import nachos.machine.Packet;

public class HMP{
	private String guess;
	private String correct;
	private String hint;

	public HMP(String correct, String hint, String guess) {
		// TODO Auto-generated constructor stub
		this.guess = guess;
		this.correct = correct;
		this.hint = hint;
	}

	public String getGuess() {
		return guess;
	}

	public void setGuess(String guess) {
		this.guess = guess;
	}

	public String getCorrect() {
		return correct;
	}

	public void setCorrect(String correct) {
		this.correct = correct;
	}

	public String getHint() {
		return hint;
	}

	public void setHint(String hint) {
		this.hint = hint;
	}
	
	public boolean attempt(char x) {
		int cL = correct.length();
		int gL = guess.length();
		boolean isCorrect = false;
		for(int i = 0; i < cL; i++) {
			if(correct.charAt(i) == x) {
				boolean isFilled = false;
				for(int j = 0; j < gL; j++) {
					if(guess.charAt(j) == x) {
						isFilled = true;
					}else {
						isFilled = false;
					}
				}
				if(isFilled) {
					isCorrect = false;
				}else {
					isCorrect = true;
				}
			}
		}
		if(isCorrect) {
			return false;
		}else {
			return true;
		}
		
	}
	
	

}
