package nachos.proj1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import nachos.machine.Kernel;
import nachos.machine.Machine;
import nachos.machine.MalformedPacketException;
import nachos.machine.NetworkLink;
import nachos.machine.Packet;
import nachos.threads.Semaphore;

public class Main {
	private static Console console;
	private static NetworkLink nl;
	private static int lives;
	private static int score;
	private static int pID;
	private static File file;
	private static HMP o;
	private static boolean isTurn;
	private static boolean isStarted;
	private static boolean isPrompt;
	private static boolean isBack;
	private static boolean inPlay;
	
	
	public Main() {
		console = new Console();
		nl = Machine.networkLink();
		file = new File("scoreboard.txt");
		this.pID = nl.getLinkAddress()+1;
		this.score = 30;
		this.lives = 3;
		this.isStarted = false;
		this.isTurn = false;
		this.isPrompt = false;
		this.isBack = false;
		this.inPlay = false;
		
		Runnable send = new Runnable() {
		
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		};
		
		Runnable receive = new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Packet pkt = nl.receive();
				int src = pkt.srcLink;
				int dest = nl.getLinkAddress();
				String content = new String(pkt.contents);
				System.out.println("Content: "+content);
				
				if(content.equals("PROMPT")) {
					isPrompt = true;
				}else if(content.equals("START")) {
					isStarted = true;
				}else if(content.equals("BACK")) {
					isBack = true;
				}else if(content.equals("NEXT")) {
					isTurn = true;
				}else {
					String[] atrs = content.split("#");
					o = new HMP(atrs[0], atrs[1], atrs[2]);
				}
			}
		};
		nl.setInterruptHandlers(receive, send);
		
		
		
		
		int choice = 0;
		
		do {
				isBack = false;
				isPrompt = false;
				isStarted = false;
				isTurn = false;
				clrscr();
				console.writeln("Hang Man [Player "+(this.pID)+"]");
				console.writeln("1. Play");
				console.writeln("2. View Scores");
				console.writeln("3. Exit");
				console.write(">> ");
				
				choice = console.readInt();
				if(choice == 1) {
					inPlay = true;
					while(inPlay) {
						if(nl.getLinkAddress() == 3) {
							sendPromptSignal();
						}
						while(isStarted == false && !isPrompt && !isBack){
							clrscr();
							console.writeln("Please wait for other players..");
						}
						if(isBack) {
							clrscr();
							console.writeln("Game start has been cancelled.");
							inPlay = false;
							pause();
							continue;
						}
						if(isPrompt) {
							clrscr();
							console.writeln("Player is enough. Start the game ? [ y / n ]");
							String confirm = "";
							while(!confirm.equals("y") && !confirm.equals("n")) {
								confirm = console.read();
							}
							if(confirm.equals("y")) {
								sendStartSignal();
								isStarted = true;
								isPrompt = false;
								isBack = false;
							}else{
								isPrompt = false;
								isStarted = false;
								sendBackSignal();
								isBack = true;
							}
						}
						if(isStarted) {
							if(nl.getLinkAddress() == 0) {
								isTurn = true;
							}
							if(o != null) {			
							if(!isTurn){
								clrscr();
								console.writeln("");
								console.writeln(o.getGuess());
								console.writeln("Hint: "+o.getHint());
								console.writeln("======================");
								console.writeln("Not your turn! Waiting..");
							}else {
								clrscr();
								console.writeln("");
								console.writeln(o.getGuess());
								console.writeln("Hint: "+o.getHint());
								console.writeln("======================");
								char letterguess = '0';
									while(letterguess < 'A' || letterguess > 'Z') {
										console.write("Input a guess letter [UPPERCASE] :");
										letterguess = console.read().charAt(0);
									}
									isTurn = false;
									console.writeln("GUESSED : "+letterguess);
									if(o.attempt(letterguess)) {
										console.writeln("CORRECT GUESS!");
										
									}else {
										console.writeln("WRONG GUESS! -1 live(s)");
										
									}
							}
							
							}
							int dest = -1;
							String word = "", hint = "", guess = "";
							ArrayList<HMP> words = new ArrayList<>();
							words.add(new HMP("GER","C",generateGuess("GER","")));
							words.add(new HMP("SPA","C",generateGuess("SPA","")));
							words.add(new HMP("FRA","C",generateGuess("FRA","")));
							words.add(new HMP("ITA","C",generateGuess("ITA","")));	
							Random r = new Random();
							int sel = r.nextInt(4);
							HMP seld = words.get(sel);
							word = seld.getCorrect();
							hint = seld.getHint();
							guess = seld.getGuess();
							o = seld;
							
							int dest1 = -1,dest2 = -1,dest3 = -1;
							
							if(isTurn) {
								if(nl.getLinkAddress() == 0) {
									dest1 = 1;
									dest2 = 2;
									dest3 = 3;
								}else if (nl.getLinkAddress() == 1){
									dest1 = 2;
									dest2 = 3;
									dest3 = 0;
								}else if (nl.getLinkAddress() == 2) {
									dest1 = 3;
									dest2 = 0;
									dest3 = 1;
								}else if (nl.getLinkAddress() == 3) {
									dest1 = 0;
									dest2 = 1;
									dest3 = 2;
								}
								isTurn = false;
								
								String content = word+"#"+hint+"#"+guess;
								String nextTurn = "NEXT";
								
								try {
									Packet pkt1 = new Packet(dest1, nl.getLinkAddress(), content.getBytes());
									Packet pkt2 = new Packet(dest2, nl.getLinkAddress(), content.getBytes());
									Packet pkt3 = new Packet(dest3, nl.getLinkAddress(), content.getBytes());
									Packet pktnext = new Packet(dest1, nl.getLinkAddress(), nextTurn.getBytes());
									nl.send(pkt1);
									nl.send(pkt2);
									nl.send(pkt3);
									nl.send(pktnext);
								} catch (MalformedPacketException e) {
									e.printStackTrace();
								}
							}
						}
					}
					
				}else if(choice ==2 ) {
					file.readScoreboard();
					file.printScoreboard();
					pause();
				}

		}while(choice !=3);
			}
			
			
	
	public String generateGuess(String correct, String guess) {
		int cL = correct.length();
		int gL = guess.length();
		String generated = "";
		for(int i = 0; i < cL; i++) {
			boolean isFilled = false;
			for(int j = 0; j < gL; j++) {
				if(guess.charAt(j) == correct.charAt(i)) {
					generated+=guess.charAt(j);
					isFilled = true;
				}
			}
			if (!isFilled) {
				generated+="_";
			}
			generated+=" ";
		}
		
		return generated;
	}
		
		
	
	public void checkTurn(HMP o) {
		String letterguess = "";
//		if(o.getTurn() == this.pID){
			while(letterguess.length() <= 0) {
				System.out.print("Input a guess letter :");
				letterguess = console.read();
			}
			System.out.println("GUESSED : "+letterguess);
			
//		}
			
	}
	
	public void sendPromptSignal() {
		if(nl.getLinkAddress() == 3) {
			String content = "PROMPT";
			
			try {
				Packet pkt1 = new Packet(0, nl.getLinkAddress(), content.getBytes());
				nl.send(pkt1);
			} catch (MalformedPacketException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void sendBackSignal() {
		if(nl.getLinkAddress() == 0) {
			String content = "BACK";
			try {
				Packet pkt1 = new Packet(1, nl.getLinkAddress(), content.getBytes());
				Packet pkt2 = new Packet(2, nl.getLinkAddress(), content.getBytes());
				Packet pkt3 = new Packet(3, nl.getLinkAddress(), content.getBytes());
				nl.send(pkt1);
				nl.send(pkt2);
				nl.send(pkt3);
				
			} catch (MalformedPacketException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void sendStartSignal() {
		if(nl.getLinkAddress() == 0) {
			String content = "START";
			
			try {
				Packet pkt1 = new Packet(1, nl.getLinkAddress(), content.getBytes());
				Packet pkt2 = new Packet(2, nl.getLinkAddress(), content.getBytes());
				Packet pkt3 = new Packet(3, nl.getLinkAddress(), content.getBytes());
				nl.send(pkt1);
				nl.send(pkt2);
				nl.send(pkt3);
				
			} catch (MalformedPacketException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void clrscr() {
		for(int i = 0; i < 60; i++) {
			System.out.println();
		}
	}
	
	public static void pause() {
        try {
            System.in.read();
        } catch (Exception e) {
        }
    }

	public static Console getConsole() {
		// TODO Auto-generated method stub
		return console;
	}


}
