package nachos.proj1;

import java.util.Random;

public class AutoOrder implements Runnable{

	public AutoOrder() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Random r = new Random();
			Random s = new Random();
			
			int quantity = r.nextInt(5) + 1;
			if(Main.getMenu().size() > 0) {
				Food food = Main.getMenu().get(s.nextInt(Main.getMenu().size()));
			
			
			if(food.isReady()) {
				Order o = new Order(food, quantity);
				Main.getOrders().add(o);
				System.out.println("[* Online Order *] "+food.getName() + " "+ food.getDuration() + " second(s)");
			}
			}
			
		}
	}

}
