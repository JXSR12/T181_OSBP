package nachos.proj1;

public class Food implements Runnable{
	private String name;
	private int duration;
	private int price;
	private boolean isReady;
	
	public Food(String name, int duration, int price, boolean isReady){
		super();
		this.name = name;
		this.duration = duration;
		this.price = price;
		this.isReady = isReady;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public boolean isReady() {
		return isReady;
	}

	public void setReady(boolean isReady) {
		this.isReady = isReady;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
			int idx = Main.getMenu().indexOf(this);
		    System.out.println("Menu "+idx+1);
		 	System.out.println("Menu's Name: "+this.name);
	        System.out.println("Menu's Price: "+this.price);
	        System.out.println("Menu's Status: "+ (this.isReady ? "Ready Stock" : "Out of Stock"));
	        System.out.println("Menu's Cook Duration: "+this.duration+" second(s)");
	        System.out.println("================================================");
	        System.out.println();
	}

	
	
	

}
