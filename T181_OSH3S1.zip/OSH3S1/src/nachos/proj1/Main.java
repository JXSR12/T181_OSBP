package nachos.proj1;

import java.util.ArrayList;
import java.util.Vector;

import nachos.threads.KThread;

public class Main {
    Console con = new Console();
    private static Vector<Order> orders = new Vector<>();
    private static Vector<Food> menu = new Vector<>();
    private static AutoOrder ao = new AutoOrder();
    private int coins;
    
    
    public Main() {
        int sel = -1;
        do {
        	clrscr();
        	con.writeln("Your Coin: "+coins);
        	con.writeln("List of menu:");
        	int cnt = 0;
        	for(Food f : menu) {
        		cnt++;
        		con.writeln(cnt+". "+f.getName()+" ("+(f.isReady() ? "Ready Stock" : "Out of Stock")+")");
        	}
        	con.writeln("");
            con.writeln("1. Add Menu");
            con.writeln("2. Update Menu");
            con.writeln("3. Remove Menu");
            con.writeln("4. Take Order");
            con.writeln("5. Process Order");
            con.writeln("0. Exit");
           sel = con.readInt();
            
           if(sel == 1) {
        	   addMenu();
           }else if(sel == 2) {
        	   updateMenu();
           }else if(sel == 3) {
        	   removeMenu();
           }else if(sel == 4) {
                takeOrder();
           }else if(sel == 5) {
                serveOrder();
           }
            
            
            
        }while(sel != 0);
    }
    
    
    
    
    private void addMenu() {
    	clrscr();
        String name = "";
        int price = 0;
        int cookdur = 0;
        do {
            con.write("Insert Menu Name [3-20 chars]: ");
            name = con.read();
        }while(name.length()< 3 || name.length() > 20);
        
        do {
            con.write("Insert Order price [$5 - $20]: ");
            price = con.readInt();
        }while(price < 5 || price > 20);
        
        do {
            con.write("Insert Cook Duration [1 - 4 second(s)]: ");
            cookdur = con.readInt();
        }while(cookdur < 1 || cookdur > 4);
        menu.add(new Food(name,cookdur,price,true));
        con.writeln("Successfully added new menu!");
        
        pause();
        
    }
    
    private void updateMenu() {
    	clrscr();
    	threadPrint();
    	int choice = -1;
    	while(choice < 1 || choice > menu.size()) {
    		con.write("Menu's index you want to update [1 - "+menu.size()+"] :");
    		choice = con.readInt();
    	}
    	choice--;
    	Food f = menu.get(choice);
    	f.setReady(f.isReady() ? false : true);
    	
    	con.writeln("Successfully updated menu!");
    	 pause();
    }
    
    private void removeMenu() {
    	clrscr();
    	threadPrint();
    	int choice = -1;
    	while(choice < 1 || choice > menu.size()) {
    		con.write("Menu's index you want to remove [1 - "+menu.size()+"] :");
    		choice = con.readInt();
    	}
    	choice--;
    	Food f = menu.get(choice);
    	menu.remove(f);
    	
    	con.writeln("Successfully removed menu!");
    	 pause();
    }
    
    private void takeOrder() {
    	clrscr();
    	int cho = -1;
    	con.writeln("1. Take Order");
    	con.writeln("0. Exit");
    	con.writeln("===================");
    	while(cho < 0 || cho > 1) {
    		con.write(">> ");
    		cho = con.readInt();
    	}
    	if(cho == 1) {
    		clrscr();
    		threadPrint();
    		int choice = -1;
        	while(choice < 1 || choice > menu.size() || !menu.get(choice-1).isReady()) {
        		con.write("Menu's index you want to order [1 - "+menu.size()+"] :");
        		choice = con.readInt();
        	}
        	choice--;
        	Food f = menu.get(choice);
        	menu.remove(f);
        	
        	int quan = -1;
        	while(quan < 1 || quan > 5) {
        		con.write("Menu quantity to order [1 - 5] : ");
        		quan = con.readInt();
        	}
        	
        	Order o = new Order(f,quan);
        	orders.add(o);
        	
        	con.writeln("Successfully added order!");
        	 pause();
    	}
    		
    	
    }
    
    
    private void serveOrder() {
        while(!orders.isEmpty()) {
            new KThread(orders.remove(0)).fork();
        }
    }
    
    private void threadPrint() {
    	for(Food f : menu) {
    		new KThread(f).fork();
    	}
    }


	public static Vector<Order> getOrders() {
		return orders;
	}


	public static Vector<Food> getMenu() {
		return menu;
	}
	
	public static void pause() {
        try {
            System.in.read();
        } catch (Exception e) {
        }
    }
	
	public static void clrscr() {
		for(int i = 0; i < 60; i++) {
			System.out.println();
		}
	}
	
    
    
    
    
    
}