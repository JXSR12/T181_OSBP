package nachos.proj1;

public class Order implements Runnable{
    private Food food;
    private int quantity;
    private int timeLeft;
    
    public Order(Food food, int quantity) {
        super();
        this.food = food;
        this.quantity = quantity;
        this.timeLeft = this.quantity * this.food.getDuration();
    }

    
    public Food getFood() {
		return food;
	}


	public void setFood(Food food) {
		this.food = food;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	@Override
    public void run() {
        // TODO Auto-generated method stub
        System.out.println("Cooking "+this.quantity+" "+this.food.getName()+" ..");
        System.out.println("Needs "+this.quantity * this.food.getDuration()+ "second(s)");
    
        try {
        	while(this.timeLeft > 0) {
        		Thread.sleep(1000);
                System.out.println(this.timeLeft-- +" seconds more..");
        	}
            System.out.println("Order "+this.food.getName()+" is completed !");
            
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    
    
    
    

}